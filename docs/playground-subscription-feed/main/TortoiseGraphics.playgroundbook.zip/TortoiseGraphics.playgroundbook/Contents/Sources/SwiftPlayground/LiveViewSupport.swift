import UIKit
import PlaygroundSupport

public func instantiateLiveView() -> LiveViewController {
    return LiveViewController()
}
