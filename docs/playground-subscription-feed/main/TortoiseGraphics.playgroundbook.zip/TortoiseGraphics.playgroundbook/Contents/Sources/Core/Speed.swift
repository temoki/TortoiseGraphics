import Foundation

public enum Speed: String, Equatable, Codable {
    case fastest
    case fast
    case normal
    case slow
    case slowest
}
